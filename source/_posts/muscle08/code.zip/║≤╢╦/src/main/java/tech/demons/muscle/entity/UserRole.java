package tech.demons.muscle.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "t_user_role")
public class UserRole {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long userId;
    private Long roleId;
}
