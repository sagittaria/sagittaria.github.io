package tech.demons.muscle.entity;

import lombok.Data;

import javax.persistence.*;

@Data
@Entity
@Table(name = "t_role_permission")
public class RolePermission {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    private Long roleId;
    private Long permissionId;
}
