package tech.demons.muscle.config.security;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.method.configuration.EnableMethodSecurity;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;
import org.springframework.security.config.annotation.web.configuration.EnableWebSecurity;
import org.springframework.security.config.annotation.web.configuration.WebSecurityConfigurerAdapter;
import org.springframework.security.config.http.SessionCreationPolicy;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.web.authentication.UsernamePasswordAuthenticationFilter;
import org.springframework.web.cors.CorsConfiguration;
import org.springframework.web.cors.CorsConfigurationSource;
import org.springframework.web.cors.UrlBasedCorsConfigurationSource;
import tech.demons.muscle.config.security.jwt.JwtAuthenticationFilter;
import tech.demons.muscle.config.security.login.MyAuthenticationEntryPoint;
import tech.demons.muscle.config.security.login.MyAuthenticationFailureHandler;
import tech.demons.muscle.config.security.login.MyAuthenticationSuccessHandler;
import tech.demons.muscle.config.security.authorization.MyAccessDeniedHandler;

import java.util.Collections;

@EnableWebSecurity
@EnableMethodSecurity
public class MySecurityConfig extends WebSecurityConfigurerAdapter {

    final MyAuthenticationSuccessHandler myAuthenticationSuccessHandler;
    final MyAuthenticationFailureHandler myAuthenticationFailureHandler;
    final MyAccessDeniedHandler myAccessDeniedHandler;
    final MyAuthenticationEntryPoint myAuthenticationEntryPoint;
    final JwtAuthenticationFilter jwtAuthenticationFilter;

    @Autowired
    public MySecurityConfig(MyAuthenticationSuccessHandler myAuthenticationSuccessHandler,
                            MyAuthenticationFailureHandler myAuthenticationFailureHandler,
                            MyAccessDeniedHandler myAccessDeniedHandler,
                            MyAuthenticationEntryPoint myAuthenticationEntryPoint,
                            JwtAuthenticationFilter jwtAuthenticationFilter) {
        this.myAuthenticationSuccessHandler = myAuthenticationSuccessHandler;
        this.myAuthenticationFailureHandler = myAuthenticationFailureHandler;
        this.myAccessDeniedHandler = myAccessDeniedHandler;
        this.myAuthenticationEntryPoint = myAuthenticationEntryPoint;
        this.jwtAuthenticationFilter = jwtAuthenticationFilter;
    }

    protected void configure(HttpSecurity http) throws Exception {
        http.csrf().disable();
        // https://docs.spring.io/spring-security/reference/servlet/authentication/logout.html
        // 文档上说了：If CSRF protection is enabled (default), then the request must also be a POST.
        // 为了直接在页面上点击个<a>注销登录（普通get请求），将csrf关掉。

        http.cors();

        http.sessionManagement().sessionCreationPolicy(SessionCreationPolicy.STATELESS);
        http
                .exceptionHandling() // 这行好像是不必要的，默认就是开启的
                .authenticationEntryPoint(myAuthenticationEntryPoint)
                .accessDeniedHandler(myAccessDeniedHandler);

        http
                .authorizeRequests(authorize -> authorize
                        .anyRequest().authenticated()
                )
                .formLogin(form -> form
                        .loginProcessingUrl("/login")
                        .successHandler(myAuthenticationSuccessHandler)
                        .failureHandler(myAuthenticationFailureHandler)
                );

        http.addFilterAfter(jwtAuthenticationFilter, UsernamePasswordAuthenticationFilter.class);
    }

    @Bean
    public BCryptPasswordEncoder bCryptPasswordEncoder() {
        return new BCryptPasswordEncoder();
    }

    @Bean
    public CorsConfigurationSource corsConfigurationSource() {
        CorsConfiguration configuration = new CorsConfiguration();
        configuration.setAllowedOrigins(Collections.singletonList("*"));
        configuration.setAllowedHeaders(Collections.singletonList("*")); // 要的，否则只要有自定义的头都会被拦掉，不允许跨域
        configuration.setAllowedMethods(Collections.singletonList("*"));
        UrlBasedCorsConfigurationSource source = new UrlBasedCorsConfigurationSource();
        source.registerCorsConfiguration("/**", configuration);
        return source;
    }
}
