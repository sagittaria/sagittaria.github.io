package tech.demons.muscle.config.security.login;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UserDetails;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;
import tech.demons.muscle.entity.*;
import tech.demons.muscle.repository.*;

import java.util.List;
import java.util.stream.Collectors;

@Service
public class MyUserDetailsService implements UserDetailsService {
    final UserRepository userRepository;
    final UserRoleRepository userRoleRepository;
    final RoleRepository roleRepository;
    final PermissionRepository permissionRepository;
    final RolePermissionRepository rolePermissionRepository;

    @Autowired
    public MyUserDetailsService(UserRepository userRepository, UserRoleRepository userRoleRepository, RoleRepository roleRepository, PermissionRepository permissionRepository, RolePermissionRepository rolePermissionRepository) {
        this.userRepository = userRepository;
        this.userRoleRepository = userRoleRepository;
        this.roleRepository = roleRepository;
        this.permissionRepository = permissionRepository;
        this.rolePermissionRepository = rolePermissionRepository;
    }

    @Override
    public UserDetails loadUserByUsername(String username) throws UsernameNotFoundException {
        User user = userRepository.findByUsername(username);
        if (user != null) {
            List<UserRole> userRoleList = userRoleRepository.findAllByUserId(user.getId());
            List<Long> roleIds = userRoleList.stream().map(UserRole::getRoleId).collect(Collectors.toList());
            List<Role> roleList = roleRepository.findAllById(roleIds);
            List<RolePermission> rolePermissionList = rolePermissionRepository.findAllByRoleIdIn(roleIds);
            List<Long> permissionIds = rolePermissionList.stream().map(RolePermission::getPermissionId).collect(Collectors.toList());
            List<Permission> permissionList = permissionRepository.findAllById(permissionIds);
            return new MyUserDetails(user, roleList, permissionList);
        } else {
            throw new UsernameNotFoundException("username not found"); // 练手项目，老实交代
        }
    }
}
