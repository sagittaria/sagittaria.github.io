package tech.demons.muscle.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tech.demons.muscle.entity.User;

public interface UserRepository extends JpaRepository<User, Long> {
    User findByUsername(String username);
}
