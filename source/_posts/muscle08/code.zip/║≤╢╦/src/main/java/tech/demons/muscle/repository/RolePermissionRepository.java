package tech.demons.muscle.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tech.demons.muscle.entity.RolePermission;

import java.util.List;

public interface RolePermissionRepository extends JpaRepository<RolePermission, Long> {
    List<RolePermission> findAllByRoleIdIn(List<Long> roleIds);
}
