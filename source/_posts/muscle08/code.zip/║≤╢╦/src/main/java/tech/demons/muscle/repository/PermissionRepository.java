package tech.demons.muscle.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tech.demons.muscle.entity.Permission;

public interface PermissionRepository extends JpaRepository<Permission, Long> {
}
