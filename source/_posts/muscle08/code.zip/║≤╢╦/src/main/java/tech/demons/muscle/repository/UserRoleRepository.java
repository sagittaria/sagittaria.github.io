package tech.demons.muscle.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tech.demons.muscle.entity.UserRole;

import java.util.List;

public interface UserRoleRepository extends JpaRepository<UserRole, Long> {
    List<UserRole> findAllByUserId(Long id);
}
