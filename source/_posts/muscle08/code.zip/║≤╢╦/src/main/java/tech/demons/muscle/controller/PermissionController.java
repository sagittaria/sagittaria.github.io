package tech.demons.muscle.controller;

import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
public class PermissionController {
    @GetMapping("/permission/saye")
    public String play() {
        return "尽情撒野"; // 只要登录了就行
    }

    @GetMapping("/permission/fanghuo")
    @PreAuthorize("hasAuthority('放火')")
    public String fire() {
        return "放起了火";
    }

    @GetMapping("/permission/diandeng")
    @PreAuthorize("hasAuthority('点灯')")
    public String light() {
        return "点亮了灯";
    }

    @GetMapping("/permission/xiaohaha")
    @PreAuthorize("hasAuthority('笑哈哈')")
    public String laugh() {
        return "笑了起来";
    }
}
