package tech.demons.muscle.repository;

import org.springframework.data.jpa.repository.JpaRepository;
import tech.demons.muscle.entity.Role;

public interface RoleRepository extends JpaRepository<Role, Long> {
}
