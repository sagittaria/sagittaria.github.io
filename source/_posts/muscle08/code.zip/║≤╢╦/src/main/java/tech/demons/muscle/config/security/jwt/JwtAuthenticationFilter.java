package tech.demons.muscle.config.security.jwt;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.core.context.SecurityContext;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;
import tech.demons.muscle.config.security.login.MyAuthenticationEntryPoint;
import tech.demons.muscle.config.security.login.MyUserDetails;
import tech.demons.muscle.entity.*;
import tech.demons.muscle.repository.*;

import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

@Component
public class JwtAuthenticationFilter extends OncePerRequestFilter {
    @Autowired
    UserRepository userRepository;
    @Autowired
    UserRoleRepository userRoleRepository;
    @Autowired
    PermissionRepository permissionRepository;
    @Autowired
    RolePermissionRepository rolePermissionRepository;
    @Autowired
    RoleRepository roleRepository;

    @Autowired
    MyAuthenticationEntryPoint myAuthenticationEntryPoint;

    @Override
    protected void doFilterInternal(HttpServletRequest request, HttpServletResponse response, FilterChain filterChain) throws ServletException, IOException {
        try {
            String token = request.getHeader("token");
            if (token == null) {
                throw new BadCredentialsException("没token，就当你没登录过");
            } else {
                User user = userRepository.findByUsername(token);
                List<UserRole> userRoleList = userRoleRepository.findAllByUserId(user.getId());
                List<Long> roleIds = userRoleList.stream().map(UserRole::getRoleId).collect(Collectors.toList());
                List<Role> roleList = roleRepository.findAllById(roleIds);
                List<RolePermission> rolePermissionList = rolePermissionRepository.findAllByRoleIdIn(roleIds);
                List<Long> permissionIds = rolePermissionList.stream().map(RolePermission::getPermissionId).collect(Collectors.toList());
                List<Permission> permissionList = permissionRepository.findAllById(permissionIds);
                MyUserDetails md = new MyUserDetails(user, roleList, permissionList);
                SecurityContext context = SecurityContextHolder.createEmptyContext();
                context.setAuthentication(new JwtAuthenticationToken(md, md.getAuthorities()));
                SecurityContextHolder.setContext(context);
            }
            filterChain.doFilter(request, response);
        } catch (AuthenticationException e) {
            SecurityContextHolder.clearContext();
            this.myAuthenticationEntryPoint.commence(request, response, e);
        }
    }
}
